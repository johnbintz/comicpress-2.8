<div id="moosemenubar">
	<ul>
		<li><a href="/feed/" class="menu-rss">RSS</a></li>
		<li><a href="http://www.uptocampink.com " class="menu-store">Store</a></li>
		<li><a href="mailto:info@uptocampink.com " class="menu-contact">Contact</a></li>
	</ul>
</div>			