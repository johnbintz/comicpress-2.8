<?php
/**
 * Syndication - Feed Count Capturing & adding comic to feed.
 * Author: Philip M. Hofer (Frumph)
 * 
 */
/*

function cp_add_to_feed_count_rss() {
	$feedcount = get_option('comicpress_feed_count_rss');
	if (!empty($feedcount)) {
		$feedcount = $feedcount + 1;
		update_option('comicpress_feed_count_rss', $feedcount);  
	} else {    
		add_option('comicpress_feed_count_rss', 1, ' ', 'yes');
	}
}

add_action('do_feed_rss', 'cp_add_to_feed_count_rss',5);


function cp_add_to_feed_count_rdf() {
	$feedcount = get_option('comicpress_feed_count_rdf');
	if (!empty($feedcount)) {
		$feedcount = $feedcount + 1;
		update_option('comicpress_feed_count_rdf', $feedcount);  
	} else {    
		add_option('comicpress_feed_count_rdf', 1, ' ', 'yes');
	}
}

add_action('do_feed_rdf', 'cp_add_to_feed_count_rdf',5);


function cp_add_to_feed_count_atom() {
	$feedcount = get_option('comicpress_feed_count_atom');
	if (!empty($feedcount)) {
		$feedcount = $feedcount + 1;
		update_option('comicpress_feed_count_atom', $feedcount);  
	} else {    
		add_option('comicpress_feed_count_atom', 1, ' ', 'yes');
	}
}

add_action('do_feed_atom', 'cp_add_to_feed_count_atom',5);

function cp_add_to_feed_count_rss2() {
	$feedcount = get_option('comicpress_feed_count_rss2');
	if (!empty($feedcount)) {
		$feedcount = $feedcount + 1;
		update_option('comicpress_feed_count_rss2', $feedcount);  
	} else {    
		add_option('comicpress_feed_count_rss2', 1, ' ', 'yes');
	}
}

add_action('do_feed_rss2', 'cp_add_to_feed_count_rss2',5);
*/
?>