<?php
/*
Widget Name: 
Widget URI: http://comicpress.org/
Description: 
Author: Philip M. Hofer (Frumph)
Version: 1.01
Author URI: http://webcomicplanet.com/

*/



?>